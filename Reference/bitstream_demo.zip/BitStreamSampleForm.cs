//*****************************************************************************
// Copyright � 2005, Bill Koukoutsis
//
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this
// list of conditions and the following disclaimer. 
//
// Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation
// and/or other materials provided with the distribution. 
//
// Neither the name of the ORGANIZATION nor the names of its contributors may
// be used to endorse or promote products derived from this software without
// specific prior written permission. 
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//*****************************************************************************

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;

using BKSystem.IO;

namespace BitStreamSample
{
	/// <summary>
	///		Summary description for BitStreamSampleForm.
	/// </summary>
	public class BitStreamSampleForm : System.Windows.Forms.Form
	{

		#region Enumerations [20051116]
		/// <summary>
		///		Defines the current BitStream operation
		/// </summary>
		private enum CurrentOp : int
		{
			/// <summary>
			///		Not reading or writing
			/// </summary>
			None = 0,
			/// <summary>
			///		Reading from the BitStream
			/// </summary>
			Read = 1,
			/// <summary>
			///		Writing to the BitStream
			/// </summary>
			Write = 2
		}

		#endregion

		
		#region Fields [20051116]
		private System.Windows.Forms.GroupBox grpBitStream;
		private System.Windows.Forms.TextBox txtBitStreamData;
		private System.Windows.Forms.TextBox txtBitStream_Capacity;
		private System.Windows.Forms.Label lblBitStream_Capacity;
		private System.Windows.Forms.TextBox txtBitStream_Length;
		private System.Windows.Forms.Label lblBitStream_Length;
		private System.Windows.Forms.TextBox txtBitStream_Position;
		private System.Windows.Forms.Label lblBitStream_Position;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TabControl tabReadWrite;
		private System.Windows.Forms.TabPage tabpRead;
		private System.Windows.Forms.TabPage tabpWrite;
		private System.Windows.Forms.Button btnWrite_Double;
		private System.Windows.Forms.TextBox txtWrite_Double_Count;
		private System.Windows.Forms.TextBox txtWrite_Double_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Double;
		private System.Windows.Forms.Label lblWrite_Double;
		private System.Windows.Forms.Button btnWrite_Single;
		private System.Windows.Forms.TextBox txtWrite_Single_Count;
		private System.Windows.Forms.TextBox txtWrite_Single_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Single;
		private System.Windows.Forms.Label lblWrite_Single;
		private System.Windows.Forms.Button btnWrite_Int64;
		private System.Windows.Forms.TextBox txtWrite_Int64_Count;
		private System.Windows.Forms.TextBox txtWrite_Int64_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Int64;
		private System.Windows.Forms.Label lblWrite_Int64;
		private System.Windows.Forms.Button btnWrite_UInt64;
		private System.Windows.Forms.TextBox txtWrite_UInt64_Count;
		private System.Windows.Forms.TextBox txtWrite_UInt64_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_UInt64;
		private System.Windows.Forms.Label lblWrite_UInt64;
		private System.Windows.Forms.Button btnWrite_Int32;
		private System.Windows.Forms.TextBox txtWrite_Int32_Count;
		private System.Windows.Forms.TextBox txtWrite_Int32_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Int32;
		private System.Windows.Forms.Label lblWrite_Int32;
		private System.Windows.Forms.Button btnWrite_UInt32;
		private System.Windows.Forms.TextBox txtWrite_UInt32_Count;
		private System.Windows.Forms.TextBox txtWrite_UInt32_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_UInt32;
		private System.Windows.Forms.Label lblWrite_UInt32;
		private System.Windows.Forms.Button btnWrite_Int16;
		private System.Windows.Forms.TextBox txtWrite_Int16_Count;
		private System.Windows.Forms.TextBox txtWrite_Int16_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Int16;
		private System.Windows.Forms.Label lblWrite_Int16;
		private System.Windows.Forms.Button btnWrite_UInt16;
		private System.Windows.Forms.TextBox txtWrite_UInt16_Count;
		private System.Windows.Forms.TextBox txtWrite_UInt16_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_UInt16;
		private System.Windows.Forms.Label lblWrite_UInt16;
		private System.Windows.Forms.Button btnWrite_SByte;
		private System.Windows.Forms.TextBox txtWrite_SByte_Count;
		private System.Windows.Forms.TextBox txtWrite_SByte_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_SByte;
		private System.Windows.Forms.Label lblWrite_SByte;
		private System.Windows.Forms.Button btnWrite_Byte;
		private System.Windows.Forms.TextBox txtWrite_Byte_Count;
		private System.Windows.Forms.TextBox txtWrite_Byte_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Byte;
		private System.Windows.Forms.Label lblWrite_Byte;
		private System.Windows.Forms.Button btnWrite_Bit;
		private System.Windows.Forms.Label lblWrite_Bit;
		private System.Windows.Forms.TextBox txtWrite_Bit;
		private System.Windows.Forms.Label lblWrite_Count;
		private System.Windows.Forms.Label lblWrite_BitIndex;
		private System.Windows.Forms.Label lblWrite_Value;
		private System.Windows.Forms.Label lblBitStream_LastWritten;
		private System.Windows.Forms.TextBox txtBitStream_LastRead;
		private System.Windows.Forms.Label lblBitStream_LastRead;
		private System.Windows.Forms.TextBox txtBitStream_LastWritten;
		private System.Windows.Forms.Label lblRead_Value;
		private System.Windows.Forms.Button btnRead_Double;
		private System.Windows.Forms.TextBox txtRead_Double_Count;
		private System.Windows.Forms.TextBox txtRead_Double_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Double;
		private System.Windows.Forms.Label lblRead_Double;
		private System.Windows.Forms.Button btnRead_Single;
		private System.Windows.Forms.TextBox txtRead_Single_Count;
		private System.Windows.Forms.TextBox txtRead_Single_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Single;
		private System.Windows.Forms.Label lblRead_Single;
		private System.Windows.Forms.Button btnRead_Int64;
		private System.Windows.Forms.TextBox txtRead_Int64_Count;
		private System.Windows.Forms.TextBox txtRead_Int64_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Int64;
		private System.Windows.Forms.Label lblRead_Int64;
		private System.Windows.Forms.Button btnRead_UInt64;
		private System.Windows.Forms.TextBox txtRead_UInt64_Count;
		private System.Windows.Forms.TextBox txtRead_UInt64_BitIndex;
		private System.Windows.Forms.TextBox txtRead_UInt64;
		private System.Windows.Forms.Label lblRead_UInt64;
		private System.Windows.Forms.Button btnRead_Int32;
		private System.Windows.Forms.TextBox txtRead_Int32_Count;
		private System.Windows.Forms.TextBox txtRead_Int32_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Int32;
		private System.Windows.Forms.Label lblRead_Int32;
		private System.Windows.Forms.Button btnRead_UInt32;
		private System.Windows.Forms.TextBox txtRead_UInt32_Count;
		private System.Windows.Forms.TextBox txtRead_UInt32_BitIndex;
		private System.Windows.Forms.TextBox txtRead_UInt32;
		private System.Windows.Forms.Label lblRead_UInt32;
		private System.Windows.Forms.Button btnRead_Int16;
		private System.Windows.Forms.TextBox txtRead_Int16_Count;
		private System.Windows.Forms.TextBox txtRead_Int16_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Int16;
		private System.Windows.Forms.Label lblRead_Int16;
		private System.Windows.Forms.Button btnRead_UInt16;
		private System.Windows.Forms.TextBox txtRead_UInt16_Count;
		private System.Windows.Forms.TextBox txtRead_UInt16_BitIndex;
		private System.Windows.Forms.TextBox txtRead_UInt16;
		private System.Windows.Forms.Label lblRead_UInt16;
		private System.Windows.Forms.Button btnRead_SByte;
		private System.Windows.Forms.TextBox txtRead_SByte_Count;
		private System.Windows.Forms.TextBox txtRead_SByte_BitIndex;
		private System.Windows.Forms.TextBox txtRead_SByte;
		private System.Windows.Forms.Label lblRead_SByte;
		private System.Windows.Forms.Button btnRead_Byte;
		private System.Windows.Forms.TextBox txtRead_Byte_Count;
		private System.Windows.Forms.TextBox txtRead_Byte_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Byte;
		private System.Windows.Forms.Label lblRead_Count;
		private System.Windows.Forms.Label lblRead_BitIndex;
		private System.Windows.Forms.Label lblRead_Byte;
		private System.Windows.Forms.Button btnRead_Bit;
		private System.Windows.Forms.Label lblRead_Bit;
		private System.Windows.Forms.TextBox txtRead_Bit;
		private System.Windows.Forms.Button btnBitStream_Position_Reset;
		private System.Windows.Forms.Button btnRead_Char;
		private System.Windows.Forms.TextBox txtRead_Char_Count;
		private System.Windows.Forms.TextBox txtRead_Char_BitIndex;
		private System.Windows.Forms.TextBox txtRead_Char;
		private System.Windows.Forms.Label lblWrite_Char;
		private System.Windows.Forms.Label lblRead_Char;
		private System.Windows.Forms.Button btnWrite_Char;
		private System.Windows.Forms.TextBox txtWrite_Char_Count;
		private System.Windows.Forms.TextBox txtWrite_Char_BitIndex;
		private System.Windows.Forms.TextBox txtWrite_Char;

		/// <summary>
		///		The current instance of the BitStream class.
		/// </summary>
		private BitStream _bstrm;
		/// <summary>
		///		The current read/write position in the BitStream class.
		/// </summary>
		private long _lCurrentPosition;
		/// <summary>
		///		The default format specifier.
		/// </summary>
		private IFormatProvider _ifp = (IFormatProvider)CultureInfo.InvariantCulture;

		#endregion


		#region ctors/dtors [20051116]
		/// <summary>
		///		Initialises the current instance of the BitStreamSampleForm class
		/// </summary>
		public BitStreamSampleForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			Application.EnableVisualStyles();
			Application.DoEvents();

			_bstrm = new BitStream();
			InitialiseFields();
		}

		#endregion


		#region Methods [20051116]
		/// <summary>
		///		Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		/// <summary>
		///		The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new BitStreamSampleForm());
		}
		/// <summary>
		///		Displays a warning message.
		/// </summary>
		private static void Warning(string message)
		{
			MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
		/// <summary>
		///		Initialises the read and write fields to default values.
		/// </summary>
		private void InitialiseFields()
		{
			txtWrite_Bit.Text = "1";
			txtWrite_Byte.Text = byte.MaxValue.ToString(_ifp); txtWrite_Byte_BitIndex.Text = "0"; txtWrite_Byte_Count.Text = "8";
			txtWrite_SByte.Text = sbyte.MinValue.ToString(_ifp); txtWrite_SByte_BitIndex.Text = "0"; txtWrite_SByte_Count.Text = "8";
			txtWrite_UInt16.Text = ushort.MaxValue.ToString(_ifp); txtWrite_UInt16_BitIndex.Text = "0"; txtWrite_UInt16_Count.Text = "16";
			txtWrite_Int16.Text = short.MinValue.ToString(_ifp); txtWrite_Int16_BitIndex.Text = "0"; txtWrite_Int16_Count.Text = "16";
			txtWrite_UInt32.Text = uint.MaxValue.ToString(_ifp); txtWrite_UInt32_BitIndex.Text = "0"; txtWrite_UInt32_Count.Text = "32";
			txtWrite_Int32.Text = int.MinValue.ToString(_ifp); txtWrite_Int32_BitIndex.Text = "0"; txtWrite_Int32_Count.Text = "32";
			txtWrite_UInt64.Text = ulong.MaxValue.ToString(_ifp); txtWrite_UInt64_BitIndex.Text = "0"; txtWrite_UInt64_Count.Text = "64";
			txtWrite_Int64.Text = long.MinValue.ToString(_ifp); txtWrite_Int64_BitIndex.Text = "0"; txtWrite_Int64_Count.Text = "64";
			txtWrite_Single.Text = (float.MinValue / 2.0f).ToString(_ifp); txtWrite_Single_BitIndex.Text = "0"; txtWrite_Single_Count.Text = "32";
			txtWrite_Double.Text = (double.MaxValue / 2.0).ToString(_ifp); txtWrite_Double_BitIndex.Text = "0"; txtWrite_Double_Count.Text = "64";
			txtWrite_Char.Text = ('A').ToString(_ifp); txtWrite_Char_BitIndex.Text = "0"; txtWrite_Char_Count.Text = "16";
			txtRead_Byte_BitIndex.Text = "0"; txtRead_Byte_Count.Text = "8";
			txtRead_SByte_BitIndex.Text = "0"; txtRead_SByte_Count.Text = "8";
			txtRead_UInt16_BitIndex.Text = "0"; txtRead_UInt16_Count.Text = "16";
			txtRead_Int16_BitIndex.Text = "0"; txtRead_Int16_Count.Text = "16";
			txtRead_UInt32_BitIndex.Text = "0"; txtRead_UInt32_Count.Text = "32";
			txtRead_Int32_BitIndex.Text = "0"; txtRead_Int32_Count.Text = "32";
			txtRead_UInt64_BitIndex.Text = "0"; txtRead_UInt64_Count.Text = "64";
			txtRead_Int64_BitIndex.Text = "0"; txtRead_Int64_Count.Text = "64";
			txtRead_Single_BitIndex.Text = "0"; txtRead_Single_Count.Text = "32";
			txtRead_Double_BitIndex.Text = "0"; txtRead_Double_Count.Text = "64";
			txtRead_Char_BitIndex.Text = "0"; txtRead_Char_Count.Text = "16";

			UpdateProperties(CurrentOp.None);

			tabReadWrite.SelectedIndex = 1;
		}
		/// <summary>
		///		Updates the current BitStream's properties after a read or write
		///		operation.
		/// </summary>
		private void UpdateProperties(CurrentOp op)
		{
			txtBitStream_Capacity.Text = _bstrm.Capacity.ToString(_ifp);
			txtBitStream_Length.Text = _bstrm.Length.ToString(_ifp);
			txtBitStream_Position.Text = _bstrm.Position.ToString(_ifp);
			txtBitStreamData.Text = _bstrm.ToString();
			if(txtBitStreamData.Text.Length != 0)
			{
				int iCount = (int)(_bstrm.Position >> 5);
				int iIndex = -1;
				for(int iCounter = 0; iCounter < iCount; iCounter++)
					iIndex = txtBitStreamData.Text.IndexOf("\r\n", iIndex + 1);
				txtBitStreamData.Focus();
				if(iIndex != -1)
					txtBitStreamData.Select(iIndex, 1);
				else
					txtBitStreamData.Select(0, 1);
				txtBitStreamData.ScrollToCaret();
			}
			if(op == CurrentOp.Write)
				txtBitStream_LastWritten.Text = (_bstrm.Position - _lCurrentPosition).ToString(_ifp);
			else if(op == CurrentOp.Read)
				txtBitStream_LastRead.Text = (_bstrm.Position - _lCurrentPosition).ToString(_ifp);
			else
			{
				txtBitStream_LastWritten.Text = "0";
				txtBitStream_LastRead.Text = "0";
			}
		}

		#region Event Handlers
		
		#region Writes [20051116]
		/// <summary>
		///		Writes a bit to the current BitStream
		/// </summary>
		private void btnWrite_Bit_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				_bstrm.Write(Convert.ToBoolean(int.Parse(txtWrite_Bit.Text, _ifp)));
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes a byte to the current BitStream
		/// </summary>
		private void btnWrite_Byte_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				byte bytBits = byte.Parse(txtWrite_Byte.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Byte_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Byte_Count.Text, _ifp);
				_bstrm.Write(bytBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an sbyte to the current BitStream
		/// </summary>
		private void btnWrite_SByte_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				sbyte sbytBits = sbyte.Parse(txtWrite_SByte.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_SByte_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_SByte_Count.Text, _ifp);
				_bstrm.Write(sbytBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an UInt16 (ushort) to the current BitStream
		/// </summary>
		private void btnWrite_UInt16_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				ushort usBits = ushort.Parse(txtWrite_UInt16.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_UInt16_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_UInt16_Count.Text, _ifp);
				_bstrm.Write(usBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an Int16 (short) to the current BitStream
		/// </summary>
		private void btnWrite_Int16_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				short sBits = short.Parse(txtWrite_Int16.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Int16_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Int16_Count.Text, _ifp);
				_bstrm.Write(sBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an UInt32 (uint) to the current BitStream
		/// </summary>
		private void btnWrite_UInt32_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				uint uiBits = uint.Parse(txtWrite_UInt32.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_UInt32_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_UInt32_Count.Text, _ifp);
				_bstrm.Write(uiBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an Int32 (int) to the current BitStream
		/// </summary>
		private void btnWrite_Int32_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				int iBits = int.Parse(txtWrite_Int32.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Int32_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Int32_Count.Text, _ifp);
				_bstrm.Write(iBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an UInt64 (ulong) to the current BitStream
		/// </summary>
		private void btnWrite_UInt64_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				ulong ulBits = ulong.Parse(txtWrite_UInt64.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_UInt64_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_UInt64_Count.Text, _ifp);
				_bstrm.Write(ulBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes an Int64 (long) to the current BitStream
		/// </summary>
		private void btnWrite_Int64_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				long lBits = long.Parse(txtWrite_Int64.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Int64_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Int64_Count.Text, _ifp);
				_bstrm.Write(lBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes a Single (float) to the current BitStream
		/// </summary>
		private void btnWrite_Single_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				float fBits = float.Parse(txtWrite_Single.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Single_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Single_Count.Text, _ifp);
				_bstrm.Write(fBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes a Double to the current BitStream
		/// </summary>
		private void btnWrite_Double_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				double dblBits = double.Parse(txtWrite_Double.Text, _ifp);
				int iBitIndex = int.Parse(txtWrite_Double_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Double_Count.Text, _ifp);
				_bstrm.Write(dblBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}
		/// <summary>
		///		Writes a Char to the current BitStream
		/// </summary>
		private void btnWrite_Char_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				char chrBits = char.Parse(txtWrite_Char.Text);
				int iBitIndex = int.Parse(txtWrite_Char_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtWrite_Char_Count.Text, _ifp);
				_bstrm.Write(chrBits, iBitIndex, iCount);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Write);
		}

		#endregion


		#region Reads [20051116]
		/// <summary>
		///		Reads a bit from the current BitStream.
		/// </summary>
		private void btnRead_Bit_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				bool blnBit = false;
				_bstrm.Read(out blnBit);
				txtRead_Bit.Text = Convert.ToInt32(blnBit).ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads a Byte from the current BitStream.
		/// </summary>
		private void btnRead_Byte_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				byte bytBits;
				int iBitIndex = int.Parse(txtRead_Byte_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Byte_Count.Text, _ifp);
				_bstrm.Read(out bytBits, iBitIndex, iCount);
				txtRead_Byte.Text = bytBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an SByte from the current BitStream.
		/// </summary>
		private void btnRead_SByte_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				sbyte sbytBits;
				int iBitIndex = int.Parse(txtRead_SByte_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_SByte_Count.Text, _ifp);
				_bstrm.Read(out sbytBits, iBitIndex, iCount);
				txtRead_SByte.Text = sbytBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an UInt16 (ushort) from the current BitStream.
		/// </summary>
		private void btnRead_UInt16_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				ushort usBits;
				int iBitIndex = int.Parse(txtRead_UInt16_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_UInt16_Count.Text, _ifp);
				_bstrm.Read(out usBits, iBitIndex, iCount);
				txtRead_UInt16.Text = usBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an Int16 (short) from the current BitStream.
		/// </summary>
		private void btnRead_Int16_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				short sBits;
				int iBitIndex = int.Parse(txtRead_Int16_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Int16_Count.Text, _ifp);
				_bstrm.Read(out sBits, iBitIndex, iCount);
				txtRead_Int16.Text = sBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an UInt32 (uint) from the current BitStream.
		/// </summary>
		private void btnRead_UInt32_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				uint uiBits;
				int iBitIndex = int.Parse(txtRead_UInt32_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_UInt32_Count.Text, _ifp);
				_bstrm.Read(out uiBits, iBitIndex, iCount);
				txtRead_UInt32.Text = uiBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an Int32 (int) from the current BitStream.
		/// </summary>
		private void btnRead_Int32_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				int iBits;
				int iBitIndex = int.Parse(txtRead_Int32_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Int32_Count.Text, _ifp);
				_bstrm.Read(out iBits, iBitIndex, iCount);
				txtRead_Int32.Text = iBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an UInt64 (ulong) from the current BitStream.
		/// </summary>
		private void btnRead_UInt64_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				ulong ulBits;
				int iBitIndex = int.Parse(txtRead_UInt64_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_UInt64_Count.Text, _ifp);
				_bstrm.Read(out ulBits, iBitIndex, iCount);
				txtRead_UInt64.Text = ulBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads an Int64 (long) from the current BitStream.
		/// </summary>
		private void btnRead_Int64_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				long lBits;
				int iBitIndex = int.Parse(txtRead_Int64_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Int64_Count.Text, _ifp);
				_bstrm.Read(out lBits, iBitIndex, iCount);
				txtRead_Int64.Text = lBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads a Single (float) from the current BitStream.
		/// </summary>
		private void btnRead_Single_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				float fBits;
				int iBitIndex = int.Parse(txtRead_Single_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Single_Count.Text, _ifp);
				_bstrm.Read(out fBits, iBitIndex, iCount);
				txtRead_Single.Text = fBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads a Double from the current BitStream.
		/// </summary>
		private void btnRead_Double_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				double dblBits;
				int iBitIndex = int.Parse(txtRead_Double_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Double_Count.Text, _ifp);
				_bstrm.Read(out dblBits, iBitIndex, iCount);
				txtRead_Double.Text = dblBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}
		/// <summary>
		///		Reads a Char from the current BitStream.
		/// </summary>
		private void btnRead_Char_Click(object sender, System.EventArgs e)
		{
			_lCurrentPosition = _bstrm.Position;
			try
			{
				char chrBits;
				int iBitIndex = int.Parse(txtRead_Char_BitIndex.Text, _ifp);
				int iCount = int.Parse(txtRead_Char_Count.Text, _ifp);
				_bstrm.Read(out chrBits, iBitIndex, iCount);
				txtRead_Char.Text = chrBits.ToString(_ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.Read);
		}

		#endregion


		/// <summary>
		///		Updates the current BitStream's position after user input.
		/// </summary>
		private void txtBitStream_Position_Leave(object sender, System.EventArgs e)
		{
			try
			{
				if(txtBitStream_Position.Text == "0" && txtBitStream_Length.Text == "0")
					return;
				else if(txtBitStream_Position.Text == txtBitStream_Length.Text)
					_bstrm.Position = long.Parse(txtBitStream_Position.Text, _ifp) - 1;
				else
					_bstrm.Position = long.Parse(txtBitStream_Position.Text, _ifp);
			}
			catch(Exception ex)
			{
				Warning(ex.Message);
			}
			UpdateProperties(CurrentOp.None);
		}
		/// <summary>
		///		Resets the current BitStream's position to 0.
		/// </summary>
		private void btnBitStream_Position_Reset_Click(object sender, System.EventArgs e)
		{
			if(_bstrm.Length > 0)
				_bstrm.Position = 0;
			UpdateProperties(CurrentOp.None);
		}

		#endregion

		#endregion


		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grpBitStream = new System.Windows.Forms.GroupBox();
			this.btnBitStream_Position_Reset = new System.Windows.Forms.Button();
			this.txtBitStream_LastRead = new System.Windows.Forms.TextBox();
			this.lblBitStream_LastRead = new System.Windows.Forms.Label();
			this.txtBitStream_LastWritten = new System.Windows.Forms.TextBox();
			this.lblBitStream_LastWritten = new System.Windows.Forms.Label();
			this.txtBitStream_Position = new System.Windows.Forms.TextBox();
			this.lblBitStream_Position = new System.Windows.Forms.Label();
			this.txtBitStream_Length = new System.Windows.Forms.TextBox();
			this.lblBitStream_Length = new System.Windows.Forms.Label();
			this.txtBitStream_Capacity = new System.Windows.Forms.TextBox();
			this.lblBitStream_Capacity = new System.Windows.Forms.Label();
			this.txtBitStreamData = new System.Windows.Forms.TextBox();
			this.tabReadWrite = new System.Windows.Forms.TabControl();
			this.tabpRead = new System.Windows.Forms.TabPage();
			this.lblRead_Value = new System.Windows.Forms.Label();
			this.btnRead_Char = new System.Windows.Forms.Button();
			this.txtRead_Char_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Char_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Char = new System.Windows.Forms.TextBox();
			this.lblRead_Char = new System.Windows.Forms.Label();
			this.btnRead_Double = new System.Windows.Forms.Button();
			this.txtRead_Double_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Double_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Double = new System.Windows.Forms.TextBox();
			this.lblRead_Double = new System.Windows.Forms.Label();
			this.btnRead_Single = new System.Windows.Forms.Button();
			this.txtRead_Single_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Single_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Single = new System.Windows.Forms.TextBox();
			this.lblRead_Single = new System.Windows.Forms.Label();
			this.btnRead_Int64 = new System.Windows.Forms.Button();
			this.txtRead_Int64_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Int64_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Int64 = new System.Windows.Forms.TextBox();
			this.lblRead_Int64 = new System.Windows.Forms.Label();
			this.btnRead_UInt64 = new System.Windows.Forms.Button();
			this.txtRead_UInt64_Count = new System.Windows.Forms.TextBox();
			this.txtRead_UInt64_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_UInt64 = new System.Windows.Forms.TextBox();
			this.lblRead_UInt64 = new System.Windows.Forms.Label();
			this.btnRead_Int32 = new System.Windows.Forms.Button();
			this.txtRead_Int32_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Int32_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Int32 = new System.Windows.Forms.TextBox();
			this.lblRead_Int32 = new System.Windows.Forms.Label();
			this.btnRead_UInt32 = new System.Windows.Forms.Button();
			this.txtRead_UInt32_Count = new System.Windows.Forms.TextBox();
			this.txtRead_UInt32_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_UInt32 = new System.Windows.Forms.TextBox();
			this.lblRead_UInt32 = new System.Windows.Forms.Label();
			this.btnRead_Int16 = new System.Windows.Forms.Button();
			this.txtRead_Int16_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Int16_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Int16 = new System.Windows.Forms.TextBox();
			this.lblRead_Int16 = new System.Windows.Forms.Label();
			this.btnRead_UInt16 = new System.Windows.Forms.Button();
			this.txtRead_UInt16_Count = new System.Windows.Forms.TextBox();
			this.txtRead_UInt16_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_UInt16 = new System.Windows.Forms.TextBox();
			this.lblRead_UInt16 = new System.Windows.Forms.Label();
			this.btnRead_SByte = new System.Windows.Forms.Button();
			this.txtRead_SByte_Count = new System.Windows.Forms.TextBox();
			this.txtRead_SByte_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_SByte = new System.Windows.Forms.TextBox();
			this.lblRead_SByte = new System.Windows.Forms.Label();
			this.btnRead_Byte = new System.Windows.Forms.Button();
			this.txtRead_Byte_Count = new System.Windows.Forms.TextBox();
			this.txtRead_Byte_BitIndex = new System.Windows.Forms.TextBox();
			this.txtRead_Byte = new System.Windows.Forms.TextBox();
			this.lblRead_Count = new System.Windows.Forms.Label();
			this.lblRead_BitIndex = new System.Windows.Forms.Label();
			this.lblRead_Byte = new System.Windows.Forms.Label();
			this.btnRead_Bit = new System.Windows.Forms.Button();
			this.lblRead_Bit = new System.Windows.Forms.Label();
			this.txtRead_Bit = new System.Windows.Forms.TextBox();
			this.tabpWrite = new System.Windows.Forms.TabPage();
			this.lblWrite_Value = new System.Windows.Forms.Label();
			this.btnWrite_Char = new System.Windows.Forms.Button();
			this.txtWrite_Char_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Char_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Char = new System.Windows.Forms.TextBox();
			this.lblWrite_Char = new System.Windows.Forms.Label();
			this.btnWrite_Double = new System.Windows.Forms.Button();
			this.txtWrite_Double_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Double_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Double = new System.Windows.Forms.TextBox();
			this.lblWrite_Double = new System.Windows.Forms.Label();
			this.btnWrite_Single = new System.Windows.Forms.Button();
			this.txtWrite_Single_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Single_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Single = new System.Windows.Forms.TextBox();
			this.lblWrite_Single = new System.Windows.Forms.Label();
			this.btnWrite_Int64 = new System.Windows.Forms.Button();
			this.txtWrite_Int64_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Int64_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Int64 = new System.Windows.Forms.TextBox();
			this.lblWrite_Int64 = new System.Windows.Forms.Label();
			this.btnWrite_UInt64 = new System.Windows.Forms.Button();
			this.txtWrite_UInt64_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt64_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt64 = new System.Windows.Forms.TextBox();
			this.lblWrite_UInt64 = new System.Windows.Forms.Label();
			this.btnWrite_Int32 = new System.Windows.Forms.Button();
			this.txtWrite_Int32_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Int32_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Int32 = new System.Windows.Forms.TextBox();
			this.lblWrite_Int32 = new System.Windows.Forms.Label();
			this.btnWrite_UInt32 = new System.Windows.Forms.Button();
			this.txtWrite_UInt32_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt32_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt32 = new System.Windows.Forms.TextBox();
			this.lblWrite_UInt32 = new System.Windows.Forms.Label();
			this.btnWrite_Int16 = new System.Windows.Forms.Button();
			this.txtWrite_Int16_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Int16_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Int16 = new System.Windows.Forms.TextBox();
			this.lblWrite_Int16 = new System.Windows.Forms.Label();
			this.btnWrite_UInt16 = new System.Windows.Forms.Button();
			this.txtWrite_UInt16_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt16_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_UInt16 = new System.Windows.Forms.TextBox();
			this.lblWrite_UInt16 = new System.Windows.Forms.Label();
			this.btnWrite_SByte = new System.Windows.Forms.Button();
			this.txtWrite_SByte_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_SByte_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_SByte = new System.Windows.Forms.TextBox();
			this.lblWrite_SByte = new System.Windows.Forms.Label();
			this.btnWrite_Byte = new System.Windows.Forms.Button();
			this.txtWrite_Byte_Count = new System.Windows.Forms.TextBox();
			this.txtWrite_Byte_BitIndex = new System.Windows.Forms.TextBox();
			this.txtWrite_Byte = new System.Windows.Forms.TextBox();
			this.lblWrite_Count = new System.Windows.Forms.Label();
			this.lblWrite_BitIndex = new System.Windows.Forms.Label();
			this.lblWrite_Byte = new System.Windows.Forms.Label();
			this.btnWrite_Bit = new System.Windows.Forms.Button();
			this.lblWrite_Bit = new System.Windows.Forms.Label();
			this.txtWrite_Bit = new System.Windows.Forms.TextBox();
			this.grpBitStream.SuspendLayout();
			this.tabReadWrite.SuspendLayout();
			this.tabpRead.SuspendLayout();
			this.tabpWrite.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpBitStream
			// 
			this.grpBitStream.Controls.Add(this.btnBitStream_Position_Reset);
			this.grpBitStream.Controls.Add(this.txtBitStream_LastRead);
			this.grpBitStream.Controls.Add(this.lblBitStream_LastRead);
			this.grpBitStream.Controls.Add(this.txtBitStream_LastWritten);
			this.grpBitStream.Controls.Add(this.lblBitStream_LastWritten);
			this.grpBitStream.Controls.Add(this.txtBitStream_Position);
			this.grpBitStream.Controls.Add(this.lblBitStream_Position);
			this.grpBitStream.Controls.Add(this.txtBitStream_Length);
			this.grpBitStream.Controls.Add(this.lblBitStream_Length);
			this.grpBitStream.Controls.Add(this.txtBitStream_Capacity);
			this.grpBitStream.Controls.Add(this.lblBitStream_Capacity);
			this.grpBitStream.Controls.Add(this.txtBitStreamData);
			this.grpBitStream.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpBitStream.Location = new System.Drawing.Point(394, 7);
			this.grpBitStream.Name = "grpBitStream";
			this.grpBitStream.Size = new System.Drawing.Size(326, 397);
			this.grpBitStream.TabIndex = 4;
			this.grpBitStream.TabStop = false;
			this.grpBitStream.Text = "&BitStream";
			// 
			// btnBitStream_Position_Reset
			// 
			this.btnBitStream_Position_Reset.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnBitStream_Position_Reset.Font = new System.Drawing.Font("Webdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnBitStream_Position_Reset.Location = new System.Drawing.Point(282, 78);
			this.btnBitStream_Position_Reset.Name = "btnBitStream_Position_Reset";
			this.btnBitStream_Position_Reset.Size = new System.Drawing.Size(24, 24);
			this.btnBitStream_Position_Reset.TabIndex = 227;
			this.btnBitStream_Position_Reset.Text = "9";
			this.btnBitStream_Position_Reset.Click += new System.EventHandler(this.btnBitStream_Position_Reset_Click);
			// 
			// txtBitStream_LastRead
			// 
			this.txtBitStream_LastRead.Location = new System.Drawing.Point(120, 132);
			this.txtBitStream_LastRead.Name = "txtBitStream_LastRead";
			this.txtBitStream_LastRead.ReadOnly = true;
			this.txtBitStream_LastRead.Size = new System.Drawing.Size(186, 21);
			this.txtBitStream_LastRead.TabIndex = 18;
			this.txtBitStream_LastRead.Text = "";
			// 
			// lblBitStream_LastRead
			// 
			this.lblBitStream_LastRead.AutoSize = true;
			this.lblBitStream_LastRead.Location = new System.Drawing.Point(24, 138);
			this.lblBitStream_LastRead.Name = "lblBitStream_LastRead";
			this.lblBitStream_LastRead.Size = new System.Drawing.Size(87, 17);
			this.lblBitStream_LastRead.TabIndex = 17;
			this.lblBitStream_LastRead.Text = "Last Read (bits):";
			// 
			// txtBitStream_LastWritten
			// 
			this.txtBitStream_LastWritten.Location = new System.Drawing.Point(120, 106);
			this.txtBitStream_LastWritten.Name = "txtBitStream_LastWritten";
			this.txtBitStream_LastWritten.ReadOnly = true;
			this.txtBitStream_LastWritten.Size = new System.Drawing.Size(186, 21);
			this.txtBitStream_LastWritten.TabIndex = 16;
			this.txtBitStream_LastWritten.Text = "";
			// 
			// lblBitStream_LastWritten
			// 
			this.lblBitStream_LastWritten.AutoSize = true;
			this.lblBitStream_LastWritten.Location = new System.Drawing.Point(24, 110);
			this.lblBitStream_LastWritten.Name = "lblBitStream_LastWritten";
			this.lblBitStream_LastWritten.Size = new System.Drawing.Size(99, 17);
			this.lblBitStream_LastWritten.TabIndex = 15;
			this.lblBitStream_LastWritten.Text = "Last Written (bits):";
			// 
			// txtBitStream_Position
			// 
			this.txtBitStream_Position.Location = new System.Drawing.Point(120, 80);
			this.txtBitStream_Position.Name = "txtBitStream_Position";
			this.txtBitStream_Position.Size = new System.Drawing.Size(158, 21);
			this.txtBitStream_Position.TabIndex = 14;
			this.txtBitStream_Position.Text = "";
			this.txtBitStream_Position.Leave += new System.EventHandler(this.txtBitStream_Position_Leave);
			// 
			// lblBitStream_Position
			// 
			this.lblBitStream_Position.AutoSize = true;
			this.lblBitStream_Position.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblBitStream_Position.Location = new System.Drawing.Point(22, 83);
			this.lblBitStream_Position.Name = "lblBitStream_Position";
			this.lblBitStream_Position.Size = new System.Drawing.Size(47, 17);
			this.lblBitStream_Position.TabIndex = 13;
			this.lblBitStream_Position.Text = "Position:";
			// 
			// txtBitStream_Length
			// 
			this.txtBitStream_Length.Location = new System.Drawing.Point(120, 54);
			this.txtBitStream_Length.Name = "txtBitStream_Length";
			this.txtBitStream_Length.ReadOnly = true;
			this.txtBitStream_Length.Size = new System.Drawing.Size(186, 21);
			this.txtBitStream_Length.TabIndex = 12;
			this.txtBitStream_Length.Text = "";
			// 
			// lblBitStream_Length
			// 
			this.lblBitStream_Length.AutoSize = true;
			this.lblBitStream_Length.Location = new System.Drawing.Point(22, 56);
			this.lblBitStream_Length.Name = "lblBitStream_Length";
			this.lblBitStream_Length.Size = new System.Drawing.Size(72, 17);
			this.lblBitStream_Length.TabIndex = 11;
			this.lblBitStream_Length.Text = "Length (bits):";
			// 
			// txtBitStream_Capacity
			// 
			this.txtBitStream_Capacity.Location = new System.Drawing.Point(120, 28);
			this.txtBitStream_Capacity.Name = "txtBitStream_Capacity";
			this.txtBitStream_Capacity.ReadOnly = true;
			this.txtBitStream_Capacity.Size = new System.Drawing.Size(186, 21);
			this.txtBitStream_Capacity.TabIndex = 10;
			this.txtBitStream_Capacity.Text = "";
			// 
			// lblBitStream_Capacity
			// 
			this.lblBitStream_Capacity.AutoSize = true;
			this.lblBitStream_Capacity.Location = new System.Drawing.Point(22, 30);
			this.lblBitStream_Capacity.Name = "lblBitStream_Capacity";
			this.lblBitStream_Capacity.Size = new System.Drawing.Size(80, 17);
			this.lblBitStream_Capacity.TabIndex = 9;
			this.lblBitStream_Capacity.Text = "Capacity (bits):";
			// 
			// txtBitStreamData
			// 
			this.txtBitStreamData.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.txtBitStreamData.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtBitStreamData.Location = new System.Drawing.Point(3, 164);
			this.txtBitStreamData.Multiline = true;
			this.txtBitStreamData.Name = "txtBitStreamData";
			this.txtBitStreamData.ReadOnly = true;
			this.txtBitStreamData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtBitStreamData.Size = new System.Drawing.Size(320, 230);
			this.txtBitStreamData.TabIndex = 0;
			this.txtBitStreamData.Text = "";
			// 
			// tabReadWrite
			// 
			this.tabReadWrite.Controls.Add(this.tabpRead);
			this.tabReadWrite.Controls.Add(this.tabpWrite);
			this.tabReadWrite.Location = new System.Drawing.Point(4, 8);
			this.tabReadWrite.Name = "tabReadWrite";
			this.tabReadWrite.SelectedIndex = 0;
			this.tabReadWrite.Size = new System.Drawing.Size(386, 396);
			this.tabReadWrite.TabIndex = 5;
			// 
			// tabpRead
			// 
			this.tabpRead.Controls.Add(this.lblRead_Value);
			this.tabpRead.Controls.Add(this.btnRead_Char);
			this.tabpRead.Controls.Add(this.txtRead_Char_Count);
			this.tabpRead.Controls.Add(this.txtRead_Char_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Char);
			this.tabpRead.Controls.Add(this.lblRead_Char);
			this.tabpRead.Controls.Add(this.btnRead_Double);
			this.tabpRead.Controls.Add(this.txtRead_Double_Count);
			this.tabpRead.Controls.Add(this.txtRead_Double_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Double);
			this.tabpRead.Controls.Add(this.lblRead_Double);
			this.tabpRead.Controls.Add(this.btnRead_Single);
			this.tabpRead.Controls.Add(this.txtRead_Single_Count);
			this.tabpRead.Controls.Add(this.txtRead_Single_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Single);
			this.tabpRead.Controls.Add(this.lblRead_Single);
			this.tabpRead.Controls.Add(this.btnRead_Int64);
			this.tabpRead.Controls.Add(this.txtRead_Int64_Count);
			this.tabpRead.Controls.Add(this.txtRead_Int64_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Int64);
			this.tabpRead.Controls.Add(this.lblRead_Int64);
			this.tabpRead.Controls.Add(this.btnRead_UInt64);
			this.tabpRead.Controls.Add(this.txtRead_UInt64_Count);
			this.tabpRead.Controls.Add(this.txtRead_UInt64_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_UInt64);
			this.tabpRead.Controls.Add(this.lblRead_UInt64);
			this.tabpRead.Controls.Add(this.btnRead_Int32);
			this.tabpRead.Controls.Add(this.txtRead_Int32_Count);
			this.tabpRead.Controls.Add(this.txtRead_Int32_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Int32);
			this.tabpRead.Controls.Add(this.lblRead_Int32);
			this.tabpRead.Controls.Add(this.btnRead_UInt32);
			this.tabpRead.Controls.Add(this.txtRead_UInt32_Count);
			this.tabpRead.Controls.Add(this.txtRead_UInt32_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_UInt32);
			this.tabpRead.Controls.Add(this.lblRead_UInt32);
			this.tabpRead.Controls.Add(this.btnRead_Int16);
			this.tabpRead.Controls.Add(this.txtRead_Int16_Count);
			this.tabpRead.Controls.Add(this.txtRead_Int16_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Int16);
			this.tabpRead.Controls.Add(this.lblRead_Int16);
			this.tabpRead.Controls.Add(this.btnRead_UInt16);
			this.tabpRead.Controls.Add(this.txtRead_UInt16_Count);
			this.tabpRead.Controls.Add(this.txtRead_UInt16_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_UInt16);
			this.tabpRead.Controls.Add(this.lblRead_UInt16);
			this.tabpRead.Controls.Add(this.btnRead_SByte);
			this.tabpRead.Controls.Add(this.txtRead_SByte_Count);
			this.tabpRead.Controls.Add(this.txtRead_SByte_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_SByte);
			this.tabpRead.Controls.Add(this.lblRead_SByte);
			this.tabpRead.Controls.Add(this.btnRead_Byte);
			this.tabpRead.Controls.Add(this.txtRead_Byte_Count);
			this.tabpRead.Controls.Add(this.txtRead_Byte_BitIndex);
			this.tabpRead.Controls.Add(this.txtRead_Byte);
			this.tabpRead.Controls.Add(this.lblRead_Count);
			this.tabpRead.Controls.Add(this.lblRead_BitIndex);
			this.tabpRead.Controls.Add(this.lblRead_Byte);
			this.tabpRead.Controls.Add(this.btnRead_Bit);
			this.tabpRead.Controls.Add(this.lblRead_Bit);
			this.tabpRead.Controls.Add(this.txtRead_Bit);
			this.tabpRead.Location = new System.Drawing.Point(4, 22);
			this.tabpRead.Name = "tabpRead";
			this.tabpRead.Size = new System.Drawing.Size(378, 370);
			this.tabpRead.TabIndex = 0;
			this.tabpRead.Text = "Read";
			// 
			// lblRead_Value
			// 
			this.lblRead_Value.AutoSize = true;
			this.lblRead_Value.Location = new System.Drawing.Point(54, 10);
			this.lblRead_Value.Name = "lblRead_Value";
			this.lblRead_Value.Size = new System.Drawing.Size(32, 17);
			this.lblRead_Value.TabIndex = 284;
			this.lblRead_Value.Text = "Value";
			// 
			// btnRead_Char
			// 
			this.btnRead_Char.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Char.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Char.Location = new System.Drawing.Point(342, 329);
			this.btnRead_Char.Name = "btnRead_Char";
			this.btnRead_Char.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Char.TabIndex = 283;
			this.btnRead_Char.Text = "$";
			this.btnRead_Char.Click += new System.EventHandler(this.btnRead_Char_Click);
			// 
			// txtRead_Char_Count
			// 
			this.txtRead_Char_Count.Location = new System.Drawing.Point(290, 329);
			this.txtRead_Char_Count.Name = "txtRead_Char_Count";
			this.txtRead_Char_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Char_Count.TabIndex = 282;
			this.txtRead_Char_Count.Text = "";
			// 
			// txtRead_Char_BitIndex
			// 
			this.txtRead_Char_BitIndex.Location = new System.Drawing.Point(234, 329);
			this.txtRead_Char_BitIndex.Name = "txtRead_Char_BitIndex";
			this.txtRead_Char_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Char_BitIndex.TabIndex = 281;
			this.txtRead_Char_BitIndex.Text = "";
			// 
			// txtRead_Char
			// 
			this.txtRead_Char.ForeColor = System.Drawing.Color.Blue;
			this.txtRead_Char.Location = new System.Drawing.Point(54, 329);
			this.txtRead_Char.Name = "txtRead_Char";
			this.txtRead_Char.ReadOnly = true;
			this.txtRead_Char.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Char.TabIndex = 280;
			this.txtRead_Char.Text = "";
			// 
			// lblRead_Char
			// 
			this.lblRead_Char.AutoSize = true;
			this.lblRead_Char.Location = new System.Drawing.Point(12, 329);
			this.lblRead_Char.Name = "lblRead_Char";
			this.lblRead_Char.Size = new System.Drawing.Size(31, 17);
			this.lblRead_Char.TabIndex = 279;
			this.lblRead_Char.Text = "Char:";
			// 
			// btnRead_Double
			// 
			this.btnRead_Double.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Double.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Double.Location = new System.Drawing.Point(342, 302);
			this.btnRead_Double.Name = "btnRead_Double";
			this.btnRead_Double.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Double.TabIndex = 278;
			this.btnRead_Double.Text = "$";
			this.btnRead_Double.Click += new System.EventHandler(this.btnRead_Double_Click);
			// 
			// txtRead_Double_Count
			// 
			this.txtRead_Double_Count.Location = new System.Drawing.Point(290, 302);
			this.txtRead_Double_Count.Name = "txtRead_Double_Count";
			this.txtRead_Double_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Double_Count.TabIndex = 277;
			this.txtRead_Double_Count.Text = "";
			// 
			// txtRead_Double_BitIndex
			// 
			this.txtRead_Double_BitIndex.Location = new System.Drawing.Point(234, 302);
			this.txtRead_Double_BitIndex.Name = "txtRead_Double_BitIndex";
			this.txtRead_Double_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Double_BitIndex.TabIndex = 276;
			this.txtRead_Double_BitIndex.Text = "";
			// 
			// txtRead_Double
			// 
			this.txtRead_Double.Location = new System.Drawing.Point(54, 302);
			this.txtRead_Double.Name = "txtRead_Double";
			this.txtRead_Double.ReadOnly = true;
			this.txtRead_Double.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Double.TabIndex = 275;
			this.txtRead_Double.Text = "";
			// 
			// lblRead_Double
			// 
			this.lblRead_Double.AutoSize = true;
			this.lblRead_Double.Location = new System.Drawing.Point(12, 302);
			this.lblRead_Double.Name = "lblRead_Double";
			this.lblRead_Double.Size = new System.Drawing.Size(43, 17);
			this.lblRead_Double.TabIndex = 274;
			this.lblRead_Double.Text = "Double:";
			// 
			// btnRead_Single
			// 
			this.btnRead_Single.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Single.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Single.Location = new System.Drawing.Point(342, 275);
			this.btnRead_Single.Name = "btnRead_Single";
			this.btnRead_Single.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Single.TabIndex = 273;
			this.btnRead_Single.Text = "$";
			this.btnRead_Single.Click += new System.EventHandler(this.btnRead_Single_Click);
			// 
			// txtRead_Single_Count
			// 
			this.txtRead_Single_Count.Location = new System.Drawing.Point(290, 275);
			this.txtRead_Single_Count.Name = "txtRead_Single_Count";
			this.txtRead_Single_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Single_Count.TabIndex = 272;
			this.txtRead_Single_Count.Text = "";
			// 
			// txtRead_Single_BitIndex
			// 
			this.txtRead_Single_BitIndex.Location = new System.Drawing.Point(234, 275);
			this.txtRead_Single_BitIndex.Name = "txtRead_Single_BitIndex";
			this.txtRead_Single_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Single_BitIndex.TabIndex = 271;
			this.txtRead_Single_BitIndex.Text = "";
			// 
			// txtRead_Single
			// 
			this.txtRead_Single.Location = new System.Drawing.Point(54, 275);
			this.txtRead_Single.Name = "txtRead_Single";
			this.txtRead_Single.ReadOnly = true;
			this.txtRead_Single.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Single.TabIndex = 270;
			this.txtRead_Single.Text = "";
			// 
			// lblRead_Single
			// 
			this.lblRead_Single.AutoSize = true;
			this.lblRead_Single.Location = new System.Drawing.Point(12, 275);
			this.lblRead_Single.Name = "lblRead_Single";
			this.lblRead_Single.Size = new System.Drawing.Size(38, 17);
			this.lblRead_Single.TabIndex = 269;
			this.lblRead_Single.Text = "Single:";
			// 
			// btnRead_Int64
			// 
			this.btnRead_Int64.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Int64.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Int64.Location = new System.Drawing.Point(342, 248);
			this.btnRead_Int64.Name = "btnRead_Int64";
			this.btnRead_Int64.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Int64.TabIndex = 268;
			this.btnRead_Int64.Text = "$";
			this.btnRead_Int64.Click += new System.EventHandler(this.btnRead_Int64_Click);
			// 
			// txtRead_Int64_Count
			// 
			this.txtRead_Int64_Count.Location = new System.Drawing.Point(290, 248);
			this.txtRead_Int64_Count.Name = "txtRead_Int64_Count";
			this.txtRead_Int64_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int64_Count.TabIndex = 267;
			this.txtRead_Int64_Count.Text = "";
			// 
			// txtRead_Int64_BitIndex
			// 
			this.txtRead_Int64_BitIndex.Location = new System.Drawing.Point(234, 248);
			this.txtRead_Int64_BitIndex.Name = "txtRead_Int64_BitIndex";
			this.txtRead_Int64_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int64_BitIndex.TabIndex = 266;
			this.txtRead_Int64_BitIndex.Text = "";
			// 
			// txtRead_Int64
			// 
			this.txtRead_Int64.Location = new System.Drawing.Point(54, 248);
			this.txtRead_Int64.Name = "txtRead_Int64";
			this.txtRead_Int64.ReadOnly = true;
			this.txtRead_Int64.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Int64.TabIndex = 265;
			this.txtRead_Int64.Text = "";
			// 
			// lblRead_Int64
			// 
			this.lblRead_Int64.AutoSize = true;
			this.lblRead_Int64.Location = new System.Drawing.Point(12, 248);
			this.lblRead_Int64.Name = "lblRead_Int64";
			this.lblRead_Int64.Size = new System.Drawing.Size(35, 17);
			this.lblRead_Int64.TabIndex = 264;
			this.lblRead_Int64.Text = "Int64:";
			// 
			// btnRead_UInt64
			// 
			this.btnRead_UInt64.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_UInt64.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_UInt64.Location = new System.Drawing.Point(342, 221);
			this.btnRead_UInt64.Name = "btnRead_UInt64";
			this.btnRead_UInt64.Size = new System.Drawing.Size(24, 24);
			this.btnRead_UInt64.TabIndex = 263;
			this.btnRead_UInt64.Text = "$";
			this.btnRead_UInt64.Click += new System.EventHandler(this.btnRead_UInt64_Click);
			// 
			// txtRead_UInt64_Count
			// 
			this.txtRead_UInt64_Count.Location = new System.Drawing.Point(290, 221);
			this.txtRead_UInt64_Count.Name = "txtRead_UInt64_Count";
			this.txtRead_UInt64_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt64_Count.TabIndex = 262;
			this.txtRead_UInt64_Count.Text = "";
			// 
			// txtRead_UInt64_BitIndex
			// 
			this.txtRead_UInt64_BitIndex.Location = new System.Drawing.Point(234, 221);
			this.txtRead_UInt64_BitIndex.Name = "txtRead_UInt64_BitIndex";
			this.txtRead_UInt64_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt64_BitIndex.TabIndex = 261;
			this.txtRead_UInt64_BitIndex.Text = "";
			// 
			// txtRead_UInt64
			// 
			this.txtRead_UInt64.Location = new System.Drawing.Point(54, 221);
			this.txtRead_UInt64.Name = "txtRead_UInt64";
			this.txtRead_UInt64.ReadOnly = true;
			this.txtRead_UInt64.Size = new System.Drawing.Size(174, 21);
			this.txtRead_UInt64.TabIndex = 260;
			this.txtRead_UInt64.Text = "";
			// 
			// lblRead_UInt64
			// 
			this.lblRead_UInt64.AutoSize = true;
			this.lblRead_UInt64.Location = new System.Drawing.Point(12, 221);
			this.lblRead_UInt64.Name = "lblRead_UInt64";
			this.lblRead_UInt64.Size = new System.Drawing.Size(42, 17);
			this.lblRead_UInt64.TabIndex = 259;
			this.lblRead_UInt64.Text = "UInt64:";
			// 
			// btnRead_Int32
			// 
			this.btnRead_Int32.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Int32.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Int32.Location = new System.Drawing.Point(342, 194);
			this.btnRead_Int32.Name = "btnRead_Int32";
			this.btnRead_Int32.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Int32.TabIndex = 258;
			this.btnRead_Int32.Text = "$";
			this.btnRead_Int32.Click += new System.EventHandler(this.btnRead_Int32_Click);
			// 
			// txtRead_Int32_Count
			// 
			this.txtRead_Int32_Count.Location = new System.Drawing.Point(290, 194);
			this.txtRead_Int32_Count.Name = "txtRead_Int32_Count";
			this.txtRead_Int32_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int32_Count.TabIndex = 257;
			this.txtRead_Int32_Count.Text = "";
			// 
			// txtRead_Int32_BitIndex
			// 
			this.txtRead_Int32_BitIndex.Location = new System.Drawing.Point(234, 194);
			this.txtRead_Int32_BitIndex.Name = "txtRead_Int32_BitIndex";
			this.txtRead_Int32_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int32_BitIndex.TabIndex = 256;
			this.txtRead_Int32_BitIndex.Text = "";
			// 
			// txtRead_Int32
			// 
			this.txtRead_Int32.Location = new System.Drawing.Point(54, 194);
			this.txtRead_Int32.Name = "txtRead_Int32";
			this.txtRead_Int32.ReadOnly = true;
			this.txtRead_Int32.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Int32.TabIndex = 255;
			this.txtRead_Int32.Text = "";
			// 
			// lblRead_Int32
			// 
			this.lblRead_Int32.AutoSize = true;
			this.lblRead_Int32.Location = new System.Drawing.Point(12, 194);
			this.lblRead_Int32.Name = "lblRead_Int32";
			this.lblRead_Int32.Size = new System.Drawing.Size(35, 17);
			this.lblRead_Int32.TabIndex = 254;
			this.lblRead_Int32.Text = "Int32:";
			// 
			// btnRead_UInt32
			// 
			this.btnRead_UInt32.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_UInt32.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_UInt32.Location = new System.Drawing.Point(342, 167);
			this.btnRead_UInt32.Name = "btnRead_UInt32";
			this.btnRead_UInt32.Size = new System.Drawing.Size(24, 24);
			this.btnRead_UInt32.TabIndex = 253;
			this.btnRead_UInt32.Text = "$";
			this.btnRead_UInt32.Click += new System.EventHandler(this.btnRead_UInt32_Click);
			// 
			// txtRead_UInt32_Count
			// 
			this.txtRead_UInt32_Count.Location = new System.Drawing.Point(290, 167);
			this.txtRead_UInt32_Count.Name = "txtRead_UInt32_Count";
			this.txtRead_UInt32_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt32_Count.TabIndex = 252;
			this.txtRead_UInt32_Count.Text = "";
			// 
			// txtRead_UInt32_BitIndex
			// 
			this.txtRead_UInt32_BitIndex.Location = new System.Drawing.Point(234, 167);
			this.txtRead_UInt32_BitIndex.Name = "txtRead_UInt32_BitIndex";
			this.txtRead_UInt32_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt32_BitIndex.TabIndex = 251;
			this.txtRead_UInt32_BitIndex.Text = "";
			// 
			// txtRead_UInt32
			// 
			this.txtRead_UInt32.Location = new System.Drawing.Point(54, 167);
			this.txtRead_UInt32.Name = "txtRead_UInt32";
			this.txtRead_UInt32.ReadOnly = true;
			this.txtRead_UInt32.Size = new System.Drawing.Size(174, 21);
			this.txtRead_UInt32.TabIndex = 250;
			this.txtRead_UInt32.Text = "";
			// 
			// lblRead_UInt32
			// 
			this.lblRead_UInt32.AutoSize = true;
			this.lblRead_UInt32.Location = new System.Drawing.Point(12, 167);
			this.lblRead_UInt32.Name = "lblRead_UInt32";
			this.lblRead_UInt32.Size = new System.Drawing.Size(42, 17);
			this.lblRead_UInt32.TabIndex = 249;
			this.lblRead_UInt32.Text = "UInt32:";
			// 
			// btnRead_Int16
			// 
			this.btnRead_Int16.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Int16.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Int16.Location = new System.Drawing.Point(342, 140);
			this.btnRead_Int16.Name = "btnRead_Int16";
			this.btnRead_Int16.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Int16.TabIndex = 248;
			this.btnRead_Int16.Text = "$";
			this.btnRead_Int16.Click += new System.EventHandler(this.btnRead_Int16_Click);
			// 
			// txtRead_Int16_Count
			// 
			this.txtRead_Int16_Count.Location = new System.Drawing.Point(290, 140);
			this.txtRead_Int16_Count.Name = "txtRead_Int16_Count";
			this.txtRead_Int16_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int16_Count.TabIndex = 247;
			this.txtRead_Int16_Count.Text = "";
			// 
			// txtRead_Int16_BitIndex
			// 
			this.txtRead_Int16_BitIndex.Location = new System.Drawing.Point(234, 140);
			this.txtRead_Int16_BitIndex.Name = "txtRead_Int16_BitIndex";
			this.txtRead_Int16_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Int16_BitIndex.TabIndex = 246;
			this.txtRead_Int16_BitIndex.Text = "";
			// 
			// txtRead_Int16
			// 
			this.txtRead_Int16.Location = new System.Drawing.Point(54, 140);
			this.txtRead_Int16.Name = "txtRead_Int16";
			this.txtRead_Int16.ReadOnly = true;
			this.txtRead_Int16.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Int16.TabIndex = 245;
			this.txtRead_Int16.Text = "";
			// 
			// lblRead_Int16
			// 
			this.lblRead_Int16.AutoSize = true;
			this.lblRead_Int16.Location = new System.Drawing.Point(12, 140);
			this.lblRead_Int16.Name = "lblRead_Int16";
			this.lblRead_Int16.Size = new System.Drawing.Size(35, 17);
			this.lblRead_Int16.TabIndex = 244;
			this.lblRead_Int16.Text = "Int16:";
			// 
			// btnRead_UInt16
			// 
			this.btnRead_UInt16.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_UInt16.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_UInt16.Location = new System.Drawing.Point(342, 113);
			this.btnRead_UInt16.Name = "btnRead_UInt16";
			this.btnRead_UInt16.Size = new System.Drawing.Size(24, 24);
			this.btnRead_UInt16.TabIndex = 243;
			this.btnRead_UInt16.Text = "$";
			this.btnRead_UInt16.Click += new System.EventHandler(this.btnRead_UInt16_Click);
			// 
			// txtRead_UInt16_Count
			// 
			this.txtRead_UInt16_Count.Location = new System.Drawing.Point(290, 113);
			this.txtRead_UInt16_Count.Name = "txtRead_UInt16_Count";
			this.txtRead_UInt16_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt16_Count.TabIndex = 242;
			this.txtRead_UInt16_Count.Text = "";
			// 
			// txtRead_UInt16_BitIndex
			// 
			this.txtRead_UInt16_BitIndex.Location = new System.Drawing.Point(234, 113);
			this.txtRead_UInt16_BitIndex.Name = "txtRead_UInt16_BitIndex";
			this.txtRead_UInt16_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_UInt16_BitIndex.TabIndex = 241;
			this.txtRead_UInt16_BitIndex.Text = "";
			// 
			// txtRead_UInt16
			// 
			this.txtRead_UInt16.Location = new System.Drawing.Point(54, 113);
			this.txtRead_UInt16.Name = "txtRead_UInt16";
			this.txtRead_UInt16.ReadOnly = true;
			this.txtRead_UInt16.Size = new System.Drawing.Size(174, 21);
			this.txtRead_UInt16.TabIndex = 240;
			this.txtRead_UInt16.Text = "";
			// 
			// lblRead_UInt16
			// 
			this.lblRead_UInt16.AutoSize = true;
			this.lblRead_UInt16.Location = new System.Drawing.Point(12, 113);
			this.lblRead_UInt16.Name = "lblRead_UInt16";
			this.lblRead_UInt16.Size = new System.Drawing.Size(42, 17);
			this.lblRead_UInt16.TabIndex = 239;
			this.lblRead_UInt16.Text = "UInt16:";
			// 
			// btnRead_SByte
			// 
			this.btnRead_SByte.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_SByte.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_SByte.Location = new System.Drawing.Point(342, 86);
			this.btnRead_SByte.Name = "btnRead_SByte";
			this.btnRead_SByte.Size = new System.Drawing.Size(24, 24);
			this.btnRead_SByte.TabIndex = 238;
			this.btnRead_SByte.Text = "$";
			this.btnRead_SByte.Click += new System.EventHandler(this.btnRead_SByte_Click);
			// 
			// txtRead_SByte_Count
			// 
			this.txtRead_SByte_Count.Location = new System.Drawing.Point(290, 86);
			this.txtRead_SByte_Count.Name = "txtRead_SByte_Count";
			this.txtRead_SByte_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_SByte_Count.TabIndex = 237;
			this.txtRead_SByte_Count.Text = "";
			// 
			// txtRead_SByte_BitIndex
			// 
			this.txtRead_SByte_BitIndex.Location = new System.Drawing.Point(234, 86);
			this.txtRead_SByte_BitIndex.Name = "txtRead_SByte_BitIndex";
			this.txtRead_SByte_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_SByte_BitIndex.TabIndex = 236;
			this.txtRead_SByte_BitIndex.Text = "";
			// 
			// txtRead_SByte
			// 
			this.txtRead_SByte.Location = new System.Drawing.Point(54, 86);
			this.txtRead_SByte.Name = "txtRead_SByte";
			this.txtRead_SByte.ReadOnly = true;
			this.txtRead_SByte.Size = new System.Drawing.Size(174, 21);
			this.txtRead_SByte.TabIndex = 235;
			this.txtRead_SByte.Text = "";
			// 
			// lblRead_SByte
			// 
			this.lblRead_SByte.AutoSize = true;
			this.lblRead_SByte.Location = new System.Drawing.Point(12, 86);
			this.lblRead_SByte.Name = "lblRead_SByte";
			this.lblRead_SByte.Size = new System.Drawing.Size(37, 17);
			this.lblRead_SByte.TabIndex = 234;
			this.lblRead_SByte.Text = "SByte:";
			// 
			// btnRead_Byte
			// 
			this.btnRead_Byte.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Byte.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Byte.Location = new System.Drawing.Point(342, 59);
			this.btnRead_Byte.Name = "btnRead_Byte";
			this.btnRead_Byte.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Byte.TabIndex = 233;
			this.btnRead_Byte.Text = "$";
			this.btnRead_Byte.Click += new System.EventHandler(this.btnRead_Byte_Click);
			// 
			// txtRead_Byte_Count
			// 
			this.txtRead_Byte_Count.Location = new System.Drawing.Point(290, 59);
			this.txtRead_Byte_Count.Name = "txtRead_Byte_Count";
			this.txtRead_Byte_Count.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Byte_Count.TabIndex = 232;
			this.txtRead_Byte_Count.Text = "";
			// 
			// txtRead_Byte_BitIndex
			// 
			this.txtRead_Byte_BitIndex.Location = new System.Drawing.Point(234, 59);
			this.txtRead_Byte_BitIndex.Name = "txtRead_Byte_BitIndex";
			this.txtRead_Byte_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtRead_Byte_BitIndex.TabIndex = 231;
			this.txtRead_Byte_BitIndex.Text = "";
			// 
			// txtRead_Byte
			// 
			this.txtRead_Byte.Location = new System.Drawing.Point(54, 59);
			this.txtRead_Byte.Name = "txtRead_Byte";
			this.txtRead_Byte.ReadOnly = true;
			this.txtRead_Byte.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Byte.TabIndex = 230;
			this.txtRead_Byte.Text = "";
			// 
			// lblRead_Count
			// 
			this.lblRead_Count.AutoSize = true;
			this.lblRead_Count.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblRead_Count.Location = new System.Drawing.Point(290, 10);
			this.lblRead_Count.Name = "lblRead_Count";
			this.lblRead_Count.Size = new System.Drawing.Size(34, 17);
			this.lblRead_Count.TabIndex = 229;
			this.lblRead_Count.Text = "Count";
			// 
			// lblRead_BitIndex
			// 
			this.lblRead_BitIndex.AutoSize = true;
			this.lblRead_BitIndex.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblRead_BitIndex.Location = new System.Drawing.Point(234, 10);
			this.lblRead_BitIndex.Name = "lblRead_BitIndex";
			this.lblRead_BitIndex.Size = new System.Drawing.Size(49, 17);
			this.lblRead_BitIndex.TabIndex = 228;
			this.lblRead_BitIndex.Text = "Bit Index";
			// 
			// lblRead_Byte
			// 
			this.lblRead_Byte.AutoSize = true;
			this.lblRead_Byte.Location = new System.Drawing.Point(12, 59);
			this.lblRead_Byte.Name = "lblRead_Byte";
			this.lblRead_Byte.Size = new System.Drawing.Size(30, 17);
			this.lblRead_Byte.TabIndex = 227;
			this.lblRead_Byte.Text = "Byte:";
			// 
			// btnRead_Bit
			// 
			this.btnRead_Bit.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnRead_Bit.Font = new System.Drawing.Font("Wingdings", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnRead_Bit.Location = new System.Drawing.Point(342, 32);
			this.btnRead_Bit.Name = "btnRead_Bit";
			this.btnRead_Bit.Size = new System.Drawing.Size(24, 24);
			this.btnRead_Bit.TabIndex = 226;
			this.btnRead_Bit.Text = "$";
			this.btnRead_Bit.Click += new System.EventHandler(this.btnRead_Bit_Click);
			// 
			// lblRead_Bit
			// 
			this.lblRead_Bit.AutoSize = true;
			this.lblRead_Bit.Location = new System.Drawing.Point(12, 32);
			this.lblRead_Bit.Name = "lblRead_Bit";
			this.lblRead_Bit.Size = new System.Drawing.Size(21, 17);
			this.lblRead_Bit.TabIndex = 224;
			this.lblRead_Bit.Text = "Bit:";
			// 
			// txtRead_Bit
			// 
			this.txtRead_Bit.ForeColor = System.Drawing.Color.Blue;
			this.txtRead_Bit.Location = new System.Drawing.Point(54, 32);
			this.txtRead_Bit.Name = "txtRead_Bit";
			this.txtRead_Bit.ReadOnly = true;
			this.txtRead_Bit.Size = new System.Drawing.Size(174, 21);
			this.txtRead_Bit.TabIndex = 225;
			this.txtRead_Bit.Text = "";
			// 
			// tabpWrite
			// 
			this.tabpWrite.Controls.Add(this.lblWrite_Value);
			this.tabpWrite.Controls.Add(this.btnWrite_Char);
			this.tabpWrite.Controls.Add(this.txtWrite_Char_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Char_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Char);
			this.tabpWrite.Controls.Add(this.lblWrite_Char);
			this.tabpWrite.Controls.Add(this.btnWrite_Double);
			this.tabpWrite.Controls.Add(this.txtWrite_Double_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Double_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Double);
			this.tabpWrite.Controls.Add(this.lblWrite_Double);
			this.tabpWrite.Controls.Add(this.btnWrite_Single);
			this.tabpWrite.Controls.Add(this.txtWrite_Single_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Single_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Single);
			this.tabpWrite.Controls.Add(this.lblWrite_Single);
			this.tabpWrite.Controls.Add(this.btnWrite_Int64);
			this.tabpWrite.Controls.Add(this.txtWrite_Int64_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Int64_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Int64);
			this.tabpWrite.Controls.Add(this.lblWrite_Int64);
			this.tabpWrite.Controls.Add(this.btnWrite_UInt64);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt64_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt64_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt64);
			this.tabpWrite.Controls.Add(this.lblWrite_UInt64);
			this.tabpWrite.Controls.Add(this.btnWrite_Int32);
			this.tabpWrite.Controls.Add(this.txtWrite_Int32_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Int32_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Int32);
			this.tabpWrite.Controls.Add(this.lblWrite_Int32);
			this.tabpWrite.Controls.Add(this.btnWrite_UInt32);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt32_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt32_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt32);
			this.tabpWrite.Controls.Add(this.lblWrite_UInt32);
			this.tabpWrite.Controls.Add(this.btnWrite_Int16);
			this.tabpWrite.Controls.Add(this.txtWrite_Int16_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Int16_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Int16);
			this.tabpWrite.Controls.Add(this.lblWrite_Int16);
			this.tabpWrite.Controls.Add(this.btnWrite_UInt16);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt16_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt16_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_UInt16);
			this.tabpWrite.Controls.Add(this.lblWrite_UInt16);
			this.tabpWrite.Controls.Add(this.btnWrite_SByte);
			this.tabpWrite.Controls.Add(this.txtWrite_SByte_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_SByte_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_SByte);
			this.tabpWrite.Controls.Add(this.lblWrite_SByte);
			this.tabpWrite.Controls.Add(this.btnWrite_Byte);
			this.tabpWrite.Controls.Add(this.txtWrite_Byte_Count);
			this.tabpWrite.Controls.Add(this.txtWrite_Byte_BitIndex);
			this.tabpWrite.Controls.Add(this.txtWrite_Byte);
			this.tabpWrite.Controls.Add(this.lblWrite_Count);
			this.tabpWrite.Controls.Add(this.lblWrite_BitIndex);
			this.tabpWrite.Controls.Add(this.lblWrite_Byte);
			this.tabpWrite.Controls.Add(this.btnWrite_Bit);
			this.tabpWrite.Controls.Add(this.lblWrite_Bit);
			this.tabpWrite.Controls.Add(this.txtWrite_Bit);
			this.tabpWrite.Location = new System.Drawing.Point(4, 22);
			this.tabpWrite.Name = "tabpWrite";
			this.tabpWrite.Size = new System.Drawing.Size(378, 370);
			this.tabpWrite.TabIndex = 1;
			this.tabpWrite.Text = "Write";
			// 
			// lblWrite_Value
			// 
			this.lblWrite_Value.AutoSize = true;
			this.lblWrite_Value.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblWrite_Value.Location = new System.Drawing.Point(54, 10);
			this.lblWrite_Value.Name = "lblWrite_Value";
			this.lblWrite_Value.Size = new System.Drawing.Size(32, 17);
			this.lblWrite_Value.TabIndex = 162;
			this.lblWrite_Value.Text = "Value";
			// 
			// btnWrite_Char
			// 
			this.btnWrite_Char.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Char.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Char.Location = new System.Drawing.Point(342, 329);
			this.btnWrite_Char.Name = "btnWrite_Char";
			this.btnWrite_Char.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Char.TabIndex = 161;
			this.btnWrite_Char.Text = "?";
			this.btnWrite_Char.Click += new System.EventHandler(this.btnWrite_Char_Click);
			// 
			// txtWrite_Char_Count
			// 
			this.txtWrite_Char_Count.Location = new System.Drawing.Point(290, 329);
			this.txtWrite_Char_Count.Name = "txtWrite_Char_Count";
			this.txtWrite_Char_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Char_Count.TabIndex = 160;
			this.txtWrite_Char_Count.Text = "";
			// 
			// txtWrite_Char_BitIndex
			// 
			this.txtWrite_Char_BitIndex.Location = new System.Drawing.Point(234, 329);
			this.txtWrite_Char_BitIndex.Name = "txtWrite_Char_BitIndex";
			this.txtWrite_Char_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Char_BitIndex.TabIndex = 159;
			this.txtWrite_Char_BitIndex.Text = "";
			// 
			// txtWrite_Char
			// 
			this.txtWrite_Char.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtWrite_Char.ForeColor = System.Drawing.Color.Blue;
			this.txtWrite_Char.Location = new System.Drawing.Point(54, 329);
			this.txtWrite_Char.Name = "txtWrite_Char";
			this.txtWrite_Char.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Char.TabIndex = 158;
			this.txtWrite_Char.Text = "";
			// 
			// lblWrite_Char
			// 
			this.lblWrite_Char.AutoSize = true;
			this.lblWrite_Char.Location = new System.Drawing.Point(12, 329);
			this.lblWrite_Char.Name = "lblWrite_Char";
			this.lblWrite_Char.Size = new System.Drawing.Size(31, 17);
			this.lblWrite_Char.TabIndex = 155;
			this.lblWrite_Char.Text = "Char:";
			// 
			// btnWrite_Double
			// 
			this.btnWrite_Double.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Double.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Double.Location = new System.Drawing.Point(342, 302);
			this.btnWrite_Double.Name = "btnWrite_Double";
			this.btnWrite_Double.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Double.TabIndex = 154;
			this.btnWrite_Double.Text = "?";
			this.btnWrite_Double.Click += new System.EventHandler(this.btnWrite_Double_Click);
			// 
			// txtWrite_Double_Count
			// 
			this.txtWrite_Double_Count.Location = new System.Drawing.Point(290, 302);
			this.txtWrite_Double_Count.Name = "txtWrite_Double_Count";
			this.txtWrite_Double_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Double_Count.TabIndex = 153;
			this.txtWrite_Double_Count.Text = "";
			// 
			// txtWrite_Double_BitIndex
			// 
			this.txtWrite_Double_BitIndex.Location = new System.Drawing.Point(234, 302);
			this.txtWrite_Double_BitIndex.Name = "txtWrite_Double_BitIndex";
			this.txtWrite_Double_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Double_BitIndex.TabIndex = 152;
			this.txtWrite_Double_BitIndex.Text = "";
			// 
			// txtWrite_Double
			// 
			this.txtWrite_Double.Location = new System.Drawing.Point(54, 302);
			this.txtWrite_Double.Name = "txtWrite_Double";
			this.txtWrite_Double.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Double.TabIndex = 151;
			this.txtWrite_Double.Text = "";
			// 
			// lblWrite_Double
			// 
			this.lblWrite_Double.AutoSize = true;
			this.lblWrite_Double.Location = new System.Drawing.Point(12, 302);
			this.lblWrite_Double.Name = "lblWrite_Double";
			this.lblWrite_Double.Size = new System.Drawing.Size(43, 17);
			this.lblWrite_Double.TabIndex = 148;
			this.lblWrite_Double.Text = "Double:";
			// 
			// btnWrite_Single
			// 
			this.btnWrite_Single.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Single.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Single.Location = new System.Drawing.Point(342, 275);
			this.btnWrite_Single.Name = "btnWrite_Single";
			this.btnWrite_Single.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Single.TabIndex = 147;
			this.btnWrite_Single.Text = "?";
			this.btnWrite_Single.Click += new System.EventHandler(this.btnWrite_Single_Click);
			// 
			// txtWrite_Single_Count
			// 
			this.txtWrite_Single_Count.Location = new System.Drawing.Point(290, 275);
			this.txtWrite_Single_Count.Name = "txtWrite_Single_Count";
			this.txtWrite_Single_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Single_Count.TabIndex = 146;
			this.txtWrite_Single_Count.Text = "";
			// 
			// txtWrite_Single_BitIndex
			// 
			this.txtWrite_Single_BitIndex.Location = new System.Drawing.Point(234, 275);
			this.txtWrite_Single_BitIndex.Name = "txtWrite_Single_BitIndex";
			this.txtWrite_Single_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Single_BitIndex.TabIndex = 145;
			this.txtWrite_Single_BitIndex.Text = "";
			// 
			// txtWrite_Single
			// 
			this.txtWrite_Single.Location = new System.Drawing.Point(54, 275);
			this.txtWrite_Single.Name = "txtWrite_Single";
			this.txtWrite_Single.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Single.TabIndex = 144;
			this.txtWrite_Single.Text = "";
			// 
			// lblWrite_Single
			// 
			this.lblWrite_Single.AutoSize = true;
			this.lblWrite_Single.Location = new System.Drawing.Point(12, 275);
			this.lblWrite_Single.Name = "lblWrite_Single";
			this.lblWrite_Single.Size = new System.Drawing.Size(38, 17);
			this.lblWrite_Single.TabIndex = 141;
			this.lblWrite_Single.Text = "Single:";
			// 
			// btnWrite_Int64
			// 
			this.btnWrite_Int64.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Int64.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Int64.Location = new System.Drawing.Point(342, 248);
			this.btnWrite_Int64.Name = "btnWrite_Int64";
			this.btnWrite_Int64.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Int64.TabIndex = 140;
			this.btnWrite_Int64.Text = "?";
			this.btnWrite_Int64.Click += new System.EventHandler(this.btnWrite_Int64_Click);
			// 
			// txtWrite_Int64_Count
			// 
			this.txtWrite_Int64_Count.Location = new System.Drawing.Point(290, 248);
			this.txtWrite_Int64_Count.Name = "txtWrite_Int64_Count";
			this.txtWrite_Int64_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int64_Count.TabIndex = 139;
			this.txtWrite_Int64_Count.Text = "";
			// 
			// txtWrite_Int64_BitIndex
			// 
			this.txtWrite_Int64_BitIndex.Location = new System.Drawing.Point(234, 248);
			this.txtWrite_Int64_BitIndex.Name = "txtWrite_Int64_BitIndex";
			this.txtWrite_Int64_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int64_BitIndex.TabIndex = 138;
			this.txtWrite_Int64_BitIndex.Text = "";
			// 
			// txtWrite_Int64
			// 
			this.txtWrite_Int64.Location = new System.Drawing.Point(54, 248);
			this.txtWrite_Int64.Name = "txtWrite_Int64";
			this.txtWrite_Int64.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Int64.TabIndex = 137;
			this.txtWrite_Int64.Text = "";
			// 
			// lblWrite_Int64
			// 
			this.lblWrite_Int64.AutoSize = true;
			this.lblWrite_Int64.Location = new System.Drawing.Point(12, 248);
			this.lblWrite_Int64.Name = "lblWrite_Int64";
			this.lblWrite_Int64.Size = new System.Drawing.Size(35, 17);
			this.lblWrite_Int64.TabIndex = 134;
			this.lblWrite_Int64.Text = "Int64:";
			// 
			// btnWrite_UInt64
			// 
			this.btnWrite_UInt64.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_UInt64.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_UInt64.Location = new System.Drawing.Point(342, 221);
			this.btnWrite_UInt64.Name = "btnWrite_UInt64";
			this.btnWrite_UInt64.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_UInt64.TabIndex = 133;
			this.btnWrite_UInt64.Text = "?";
			this.btnWrite_UInt64.Click += new System.EventHandler(this.btnWrite_UInt64_Click);
			// 
			// txtWrite_UInt64_Count
			// 
			this.txtWrite_UInt64_Count.Location = new System.Drawing.Point(290, 221);
			this.txtWrite_UInt64_Count.Name = "txtWrite_UInt64_Count";
			this.txtWrite_UInt64_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt64_Count.TabIndex = 132;
			this.txtWrite_UInt64_Count.Text = "";
			// 
			// txtWrite_UInt64_BitIndex
			// 
			this.txtWrite_UInt64_BitIndex.Location = new System.Drawing.Point(234, 221);
			this.txtWrite_UInt64_BitIndex.Name = "txtWrite_UInt64_BitIndex";
			this.txtWrite_UInt64_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt64_BitIndex.TabIndex = 131;
			this.txtWrite_UInt64_BitIndex.Text = "";
			// 
			// txtWrite_UInt64
			// 
			this.txtWrite_UInt64.Location = new System.Drawing.Point(54, 221);
			this.txtWrite_UInt64.Name = "txtWrite_UInt64";
			this.txtWrite_UInt64.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_UInt64.TabIndex = 130;
			this.txtWrite_UInt64.Text = "";
			// 
			// lblWrite_UInt64
			// 
			this.lblWrite_UInt64.AutoSize = true;
			this.lblWrite_UInt64.Location = new System.Drawing.Point(12, 221);
			this.lblWrite_UInt64.Name = "lblWrite_UInt64";
			this.lblWrite_UInt64.Size = new System.Drawing.Size(42, 17);
			this.lblWrite_UInt64.TabIndex = 127;
			this.lblWrite_UInt64.Text = "UInt64:";
			// 
			// btnWrite_Int32
			// 
			this.btnWrite_Int32.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Int32.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Int32.Location = new System.Drawing.Point(342, 194);
			this.btnWrite_Int32.Name = "btnWrite_Int32";
			this.btnWrite_Int32.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Int32.TabIndex = 126;
			this.btnWrite_Int32.Text = "?";
			this.btnWrite_Int32.Click += new System.EventHandler(this.btnWrite_Int32_Click);
			// 
			// txtWrite_Int32_Count
			// 
			this.txtWrite_Int32_Count.Location = new System.Drawing.Point(290, 194);
			this.txtWrite_Int32_Count.Name = "txtWrite_Int32_Count";
			this.txtWrite_Int32_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int32_Count.TabIndex = 125;
			this.txtWrite_Int32_Count.Text = "";
			// 
			// txtWrite_Int32_BitIndex
			// 
			this.txtWrite_Int32_BitIndex.Location = new System.Drawing.Point(234, 194);
			this.txtWrite_Int32_BitIndex.Name = "txtWrite_Int32_BitIndex";
			this.txtWrite_Int32_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int32_BitIndex.TabIndex = 124;
			this.txtWrite_Int32_BitIndex.Text = "";
			// 
			// txtWrite_Int32
			// 
			this.txtWrite_Int32.Location = new System.Drawing.Point(54, 194);
			this.txtWrite_Int32.Name = "txtWrite_Int32";
			this.txtWrite_Int32.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Int32.TabIndex = 123;
			this.txtWrite_Int32.Text = "";
			// 
			// lblWrite_Int32
			// 
			this.lblWrite_Int32.AutoSize = true;
			this.lblWrite_Int32.Location = new System.Drawing.Point(12, 194);
			this.lblWrite_Int32.Name = "lblWrite_Int32";
			this.lblWrite_Int32.Size = new System.Drawing.Size(35, 17);
			this.lblWrite_Int32.TabIndex = 120;
			this.lblWrite_Int32.Text = "Int32:";
			// 
			// btnWrite_UInt32
			// 
			this.btnWrite_UInt32.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_UInt32.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_UInt32.Location = new System.Drawing.Point(342, 167);
			this.btnWrite_UInt32.Name = "btnWrite_UInt32";
			this.btnWrite_UInt32.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_UInt32.TabIndex = 119;
			this.btnWrite_UInt32.Text = "?";
			this.btnWrite_UInt32.Click += new System.EventHandler(this.btnWrite_UInt32_Click);
			// 
			// txtWrite_UInt32_Count
			// 
			this.txtWrite_UInt32_Count.Location = new System.Drawing.Point(290, 167);
			this.txtWrite_UInt32_Count.Name = "txtWrite_UInt32_Count";
			this.txtWrite_UInt32_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt32_Count.TabIndex = 118;
			this.txtWrite_UInt32_Count.Text = "";
			// 
			// txtWrite_UInt32_BitIndex
			// 
			this.txtWrite_UInt32_BitIndex.Location = new System.Drawing.Point(234, 167);
			this.txtWrite_UInt32_BitIndex.Name = "txtWrite_UInt32_BitIndex";
			this.txtWrite_UInt32_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt32_BitIndex.TabIndex = 117;
			this.txtWrite_UInt32_BitIndex.Text = "";
			// 
			// txtWrite_UInt32
			// 
			this.txtWrite_UInt32.Location = new System.Drawing.Point(54, 167);
			this.txtWrite_UInt32.Name = "txtWrite_UInt32";
			this.txtWrite_UInt32.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_UInt32.TabIndex = 116;
			this.txtWrite_UInt32.Text = "";
			// 
			// lblWrite_UInt32
			// 
			this.lblWrite_UInt32.AutoSize = true;
			this.lblWrite_UInt32.Location = new System.Drawing.Point(12, 167);
			this.lblWrite_UInt32.Name = "lblWrite_UInt32";
			this.lblWrite_UInt32.Size = new System.Drawing.Size(42, 17);
			this.lblWrite_UInt32.TabIndex = 113;
			this.lblWrite_UInt32.Text = "UInt32:";
			// 
			// btnWrite_Int16
			// 
			this.btnWrite_Int16.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Int16.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Int16.Location = new System.Drawing.Point(342, 140);
			this.btnWrite_Int16.Name = "btnWrite_Int16";
			this.btnWrite_Int16.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Int16.TabIndex = 112;
			this.btnWrite_Int16.Text = "?";
			this.btnWrite_Int16.Click += new System.EventHandler(this.btnWrite_Int16_Click);
			// 
			// txtWrite_Int16_Count
			// 
			this.txtWrite_Int16_Count.Location = new System.Drawing.Point(290, 140);
			this.txtWrite_Int16_Count.Name = "txtWrite_Int16_Count";
			this.txtWrite_Int16_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int16_Count.TabIndex = 111;
			this.txtWrite_Int16_Count.Text = "";
			// 
			// txtWrite_Int16_BitIndex
			// 
			this.txtWrite_Int16_BitIndex.Location = new System.Drawing.Point(234, 140);
			this.txtWrite_Int16_BitIndex.Name = "txtWrite_Int16_BitIndex";
			this.txtWrite_Int16_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Int16_BitIndex.TabIndex = 110;
			this.txtWrite_Int16_BitIndex.Text = "";
			// 
			// txtWrite_Int16
			// 
			this.txtWrite_Int16.Location = new System.Drawing.Point(54, 140);
			this.txtWrite_Int16.Name = "txtWrite_Int16";
			this.txtWrite_Int16.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Int16.TabIndex = 109;
			this.txtWrite_Int16.Text = "";
			// 
			// lblWrite_Int16
			// 
			this.lblWrite_Int16.AutoSize = true;
			this.lblWrite_Int16.Location = new System.Drawing.Point(12, 140);
			this.lblWrite_Int16.Name = "lblWrite_Int16";
			this.lblWrite_Int16.Size = new System.Drawing.Size(35, 17);
			this.lblWrite_Int16.TabIndex = 106;
			this.lblWrite_Int16.Text = "Int16:";
			// 
			// btnWrite_UInt16
			// 
			this.btnWrite_UInt16.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_UInt16.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_UInt16.Location = new System.Drawing.Point(342, 113);
			this.btnWrite_UInt16.Name = "btnWrite_UInt16";
			this.btnWrite_UInt16.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_UInt16.TabIndex = 105;
			this.btnWrite_UInt16.Text = "?";
			this.btnWrite_UInt16.Click += new System.EventHandler(this.btnWrite_UInt16_Click);
			// 
			// txtWrite_UInt16_Count
			// 
			this.txtWrite_UInt16_Count.Location = new System.Drawing.Point(290, 113);
			this.txtWrite_UInt16_Count.Name = "txtWrite_UInt16_Count";
			this.txtWrite_UInt16_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt16_Count.TabIndex = 104;
			this.txtWrite_UInt16_Count.Text = "";
			// 
			// txtWrite_UInt16_BitIndex
			// 
			this.txtWrite_UInt16_BitIndex.Location = new System.Drawing.Point(234, 113);
			this.txtWrite_UInt16_BitIndex.Name = "txtWrite_UInt16_BitIndex";
			this.txtWrite_UInt16_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_UInt16_BitIndex.TabIndex = 103;
			this.txtWrite_UInt16_BitIndex.Text = "";
			// 
			// txtWrite_UInt16
			// 
			this.txtWrite_UInt16.Location = new System.Drawing.Point(54, 113);
			this.txtWrite_UInt16.Name = "txtWrite_UInt16";
			this.txtWrite_UInt16.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_UInt16.TabIndex = 102;
			this.txtWrite_UInt16.Text = "";
			// 
			// lblWrite_UInt16
			// 
			this.lblWrite_UInt16.AutoSize = true;
			this.lblWrite_UInt16.Location = new System.Drawing.Point(12, 113);
			this.lblWrite_UInt16.Name = "lblWrite_UInt16";
			this.lblWrite_UInt16.Size = new System.Drawing.Size(42, 17);
			this.lblWrite_UInt16.TabIndex = 99;
			this.lblWrite_UInt16.Text = "UInt16:";
			// 
			// btnWrite_SByte
			// 
			this.btnWrite_SByte.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_SByte.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_SByte.Location = new System.Drawing.Point(342, 86);
			this.btnWrite_SByte.Name = "btnWrite_SByte";
			this.btnWrite_SByte.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_SByte.TabIndex = 98;
			this.btnWrite_SByte.Text = "?";
			this.btnWrite_SByte.Click += new System.EventHandler(this.btnWrite_SByte_Click);
			// 
			// txtWrite_SByte_Count
			// 
			this.txtWrite_SByte_Count.Location = new System.Drawing.Point(290, 86);
			this.txtWrite_SByte_Count.Name = "txtWrite_SByte_Count";
			this.txtWrite_SByte_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_SByte_Count.TabIndex = 97;
			this.txtWrite_SByte_Count.Text = "";
			// 
			// txtWrite_SByte_BitIndex
			// 
			this.txtWrite_SByte_BitIndex.Location = new System.Drawing.Point(234, 86);
			this.txtWrite_SByte_BitIndex.Name = "txtWrite_SByte_BitIndex";
			this.txtWrite_SByte_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_SByte_BitIndex.TabIndex = 96;
			this.txtWrite_SByte_BitIndex.Text = "";
			// 
			// txtWrite_SByte
			// 
			this.txtWrite_SByte.Location = new System.Drawing.Point(54, 86);
			this.txtWrite_SByte.Name = "txtWrite_SByte";
			this.txtWrite_SByte.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_SByte.TabIndex = 95;
			this.txtWrite_SByte.Text = "";
			// 
			// lblWrite_SByte
			// 
			this.lblWrite_SByte.AutoSize = true;
			this.lblWrite_SByte.Location = new System.Drawing.Point(12, 86);
			this.lblWrite_SByte.Name = "lblWrite_SByte";
			this.lblWrite_SByte.Size = new System.Drawing.Size(37, 17);
			this.lblWrite_SByte.TabIndex = 92;
			this.lblWrite_SByte.Text = "SByte:";
			// 
			// btnWrite_Byte
			// 
			this.btnWrite_Byte.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Byte.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Byte.Location = new System.Drawing.Point(342, 59);
			this.btnWrite_Byte.Name = "btnWrite_Byte";
			this.btnWrite_Byte.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Byte.TabIndex = 91;
			this.btnWrite_Byte.Text = "?";
			this.btnWrite_Byte.Click += new System.EventHandler(this.btnWrite_Byte_Click);
			// 
			// txtWrite_Byte_Count
			// 
			this.txtWrite_Byte_Count.Location = new System.Drawing.Point(290, 59);
			this.txtWrite_Byte_Count.Name = "txtWrite_Byte_Count";
			this.txtWrite_Byte_Count.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Byte_Count.TabIndex = 90;
			this.txtWrite_Byte_Count.Text = "";
			// 
			// txtWrite_Byte_BitIndex
			// 
			this.txtWrite_Byte_BitIndex.Location = new System.Drawing.Point(234, 59);
			this.txtWrite_Byte_BitIndex.Name = "txtWrite_Byte_BitIndex";
			this.txtWrite_Byte_BitIndex.Size = new System.Drawing.Size(49, 21);
			this.txtWrite_Byte_BitIndex.TabIndex = 89;
			this.txtWrite_Byte_BitIndex.Text = "";
			// 
			// txtWrite_Byte
			// 
			this.txtWrite_Byte.Location = new System.Drawing.Point(54, 59);
			this.txtWrite_Byte.Name = "txtWrite_Byte";
			this.txtWrite_Byte.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Byte.TabIndex = 88;
			this.txtWrite_Byte.Text = "";
			// 
			// lblWrite_Count
			// 
			this.lblWrite_Count.AutoSize = true;
			this.lblWrite_Count.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblWrite_Count.Location = new System.Drawing.Point(290, 10);
			this.lblWrite_Count.Name = "lblWrite_Count";
			this.lblWrite_Count.Size = new System.Drawing.Size(34, 17);
			this.lblWrite_Count.TabIndex = 87;
			this.lblWrite_Count.Text = "Count";
			// 
			// lblWrite_BitIndex
			// 
			this.lblWrite_BitIndex.AutoSize = true;
			this.lblWrite_BitIndex.ForeColor = System.Drawing.Color.DarkBlue;
			this.lblWrite_BitIndex.Location = new System.Drawing.Point(234, 10);
			this.lblWrite_BitIndex.Name = "lblWrite_BitIndex";
			this.lblWrite_BitIndex.Size = new System.Drawing.Size(49, 17);
			this.lblWrite_BitIndex.TabIndex = 86;
			this.lblWrite_BitIndex.Text = "Bit Index";
			// 
			// lblWrite_Byte
			// 
			this.lblWrite_Byte.AutoSize = true;
			this.lblWrite_Byte.Location = new System.Drawing.Point(12, 59);
			this.lblWrite_Byte.Name = "lblWrite_Byte";
			this.lblWrite_Byte.Size = new System.Drawing.Size(30, 17);
			this.lblWrite_Byte.TabIndex = 85;
			this.lblWrite_Byte.Text = "Byte:";
			// 
			// btnWrite_Bit
			// 
			this.btnWrite_Bit.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWrite_Bit.Font = new System.Drawing.Font("Wingdings", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.btnWrite_Bit.Location = new System.Drawing.Point(342, 32);
			this.btnWrite_Bit.Name = "btnWrite_Bit";
			this.btnWrite_Bit.Size = new System.Drawing.Size(24, 24);
			this.btnWrite_Bit.TabIndex = 84;
			this.btnWrite_Bit.Text = "?";
			this.btnWrite_Bit.Click += new System.EventHandler(this.btnWrite_Bit_Click);
			// 
			// lblWrite_Bit
			// 
			this.lblWrite_Bit.AutoSize = true;
			this.lblWrite_Bit.Location = new System.Drawing.Point(12, 32);
			this.lblWrite_Bit.Name = "lblWrite_Bit";
			this.lblWrite_Bit.Size = new System.Drawing.Size(21, 17);
			this.lblWrite_Bit.TabIndex = 82;
			this.lblWrite_Bit.Text = "Bit:";
			// 
			// txtWrite_Bit
			// 
			this.txtWrite_Bit.ForeColor = System.Drawing.Color.Blue;
			this.txtWrite_Bit.Location = new System.Drawing.Point(54, 32);
			this.txtWrite_Bit.Name = "txtWrite_Bit";
			this.txtWrite_Bit.Size = new System.Drawing.Size(174, 21);
			this.txtWrite_Bit.TabIndex = 83;
			this.txtWrite_Bit.Text = "";
			// 
			// BitStreamSampleForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(724, 408);
			this.Controls.Add(this.tabReadWrite);
			this.Controls.Add(this.grpBitStream);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "BitStreamSampleForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "BitStream Sample";
			this.grpBitStream.ResumeLayout(false);
			this.tabReadWrite.ResumeLayout(false);
			this.tabpRead.ResumeLayout(false);
			this.tabpWrite.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


	}
}
